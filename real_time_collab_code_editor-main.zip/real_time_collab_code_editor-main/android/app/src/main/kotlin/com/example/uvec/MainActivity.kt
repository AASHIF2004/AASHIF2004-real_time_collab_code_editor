package com.example.uvec

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
